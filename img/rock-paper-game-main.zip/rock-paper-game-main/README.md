# rock-paper-game

An assignment for the ODIN PROJECT 

